TABLE_MAPPING: dict[str, str] = {
    "user_activity": "idempotent",
    "daily_activity": "idempotent"
}
